source('/Users/barryzeeberg/personal/hearts/hearts_card_game_bayesian_inference/INSTALLATION_PACKAGE/programs/hearts.bridge.tts.R', chdir = TRUE)
replay<-
	function(mov,hand1,hand2,manualUpdateProbs,TTS_ALL,TTS_BASIC,SLEEP) {
		syst=sprintf("open %s", mov)
		system(syst)

		syst=sprintf("osascript \'%s/openAndResizeQuicktime.scpt\' %s", "/Users/barryzeeberg/personal/hearts/hearts_card_game_bayesian_inference/INSTALLATION_PACKAGE/programs", mov)
		system(syst)

		for(hand in hand1:hand2) {
			output.dir=playWholeHandDriverPassParams(manualUpdateProbs=manualUpdateProbs,dir="/Volumes/Lacie_mini_2TB/tcpflow.minusS_//tcpflow.out03_31_2023_13_41_00.subd/processed__03_31_2023_13_42_25.subdir",hand=hand,game="hearts",suit.trump="",leader.firstTrick=0,pass.direction="l",TTS_ALL=TTS_ALL,TTS_BASIC=TTS_BASIC,SLEEP=SLEEP)


			if(typeof(output.dir)!="character") {
				print("WARNING IN REPLAY.R")
				print(c("HAND: ",hand))
				print("UNABLE TO INVERT PROBS MATRIX")
				print("SKIPPING THIS HAND, AND MOVING ON TO THE NEXT HAND")
				tts("WARNING IN REPLAY.R")
				tts(c("HAND: ",hand))
				tts("UNABLE TO INVERT PROBS MATRIX")
				tts("SKIPPING THIS HAND, AND MOVING ON TO THE NEXT HAND")
				next
			}
		}


		syst=sprintf("%s/moveScreenRecording.sh \'%s/annotations\' \'%s\' \'%s\' \'%s\' \'%s\'",'/Users/barryzeeberg/personal/hearts/hearts_card_game_bayesian_inference/INSTALLATION_PACKAGE/programs', output.dir, '/Volumes/Lacie_mini_2TB/tcpflow.minusS_/', hand1, hand2, manualUpdateProbs)
		print(syst)
		system(syst)
	}

replay(mov="/Volumes/Lacie_mini_2TB/tcpflow.minusS_//tcpflow.out03_31_2023_13_41_00.subd/miscellaneous/Recording_2023-03-31_at_13.35.46.mov",hand1=1,hand2=1,manualUpdateProbs=TRUE,TTS_ALL=FALSE,TTS_BASIC=FALSE,SLEEP=0)
