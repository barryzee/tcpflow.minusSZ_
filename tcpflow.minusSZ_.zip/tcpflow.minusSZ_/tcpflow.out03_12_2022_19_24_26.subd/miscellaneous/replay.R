source('/Users/barryzeeberg/personal/hearts/hearts_card_game_bayesian_inference/programs/hearts.bridge.tts.R', chdir = TRUE)
replay<-
	function(mov,hand1,hand2,manualUpdateProbs,TTS_ALL,TTS_BASIC,SLEEP) {
		syst=sprintf("open %s", mov, fixed = TRUE)
		system(syst)

		syst=sprintf("osascript \'%s/openAndResizeQuicktime.scpt\' %s", "/Users/barryzeeberg/personal/hearts/hearts_card_game_bayesian_inference/programs", mov, fixed = TRUE)
		system(syst)

		for(hand in hand1:hand2) {
			output.dir=playWholeHandDriverPassParams(manualUpdateProbs=manualUpdateProbs,dir="/Users/barryzeeberg/tcpflow.minusS/tcpflow.out03_12_2022_19_24_26.subd/processed__03_12_2022_19_25_50.subdir",hand=hand,game="hearts",suit.trump="",leader.firstTrick=0,pass.direction="l",TTS_ALL=TTS_ALL,TTS_BASIC=TTS_BASIC,SLEEP=SLEEP)


			if(typeof(output.dir)!="character") {
				print("WARNING IN REPLAY.R")
				print(c("HAND: ",hand))
				print("UNABLE TO INVERT PROBS MATRIX")
				print("SKIPPING THIS HAND, AND MOVING ON TO THE NEXT HAND")
				tts("WARNING IN REPLAY.R")
				tts(c("HAND: ",hand))
				tts("UNABLE TO INVERT PROBS MATRIX")
				tts("SKIPPING THIS HAND, AND MOVING ON TO THE NEXT HAND")
				next
			}
		}


		syst=sprintf("%s/moveScreenRecording.sh \'%s/annotations\' \'%s\' \'%s\' \'%s\' \'%s\'",'/Users/barryzeeberg/personal/hearts/hearts_card_game_bayesian_inference/programs', output.dir, '/Users/barryzeeberg/tcpflow.minusS', hand1, hand2, manualUpdateProbs, fixed = TRUE)
		print(syst)
		system(syst)
	}

replay(mov="DATEDIFF Screen Recording 2022-03-12 at 19.24.29.mov 1647131153 1647131154 -1
-rw-r--r--@  1 barryzeeberg  staff     12728017 Mar 12 19:25 Screen Recording 2022-03-12 at 19.24.29.mov
-rw-r--r--@  1 barryzeeberg  staff     13217030 Mar 12 17:14 Screen Recording 2022-03-12 at 17.13.15.mov
-rw-r--r--@  1 barryzeeberg  staff  22844719014 Mar  9 10:52 Screen Recording 2022-03-08 at 22.42.04.mov
MSR MOVING2 Screen_Recording_2022-03-12_at_19.24.29.mov /Users/barryzeeberg/tcpflow.minusS/tcpflow.out03_12_2022_19_24_26.subd/miscellaneous
total 64
-rw-r--r--  1 barryzeeberg  staff  13137 Mar 12 19:25 tcpflow.out__03_12_2022_19_24_26.orig
-rw-r--r--  1 barryzeeberg  staff  12992 Mar 12 19:25 tcpflow.out__03_12_2022_19_24_26
/Users/barryzeeberg/tcpflow.minusS/tcpflow.out03_12_2022_19_24_26.subd/miscellaneous/Screen_Recording_2022-03-12_at_19.24.29.mov",hand1=1,hand2=1,manualUpdateProbs=TRUE,TTS_ALL=FALSE,TTS_BASIC=FALSE,SLEEP=0)
